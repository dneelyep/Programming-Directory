
function typeaheadpro(obj,source,properties){if(!typeaheadpro.hacks){typeaheadpro.should_check_missing_events=ua.safari()<500;typeaheadpro.should_use_iframe=typeaheadpro.should_simulate_keypress=ua.ie()||(ua.safari()>500&&ua.safari()<523);typeaheadpro.should_use_overflow=ua.opera()<9.5||ua.safari()<500;typeaheadpro.hacks=true;}
typeaheadpro.instances=(typeaheadpro.instances||[]);typeaheadpro.instances.push(this);this.instance=typeaheadpro.instances.length-1;copy_properties(this,properties||{});this.obj=obj;this.obj.typeahead=this;this.obj.onfocus=this._onfocus.bind(this);this.obj.onblur=chain(this.obj.onblur,this._onblur.bind(this));this.obj.onchange=this._onchange.bind(this);this.obj.onkeyup=function(event){return this._onkeyup(event||window.event);}.bind(this);this.obj.onkeydown=function(event){return this._onkeydown(event||window.event);}.bind(this);this.obj.onkeypress=function(event){return this._onkeypress(event||window.event);}.bind(this);this.focused=this.obj.offsetWidth?true:false;this.anchor=this.setup_anchor();this.dropdown=document.createElement('div');this.dropdown.className='typeahead_list';if(!this.focused){this.dropdown.style.display='none';}
this.anchor_block=this.anchor_block||this.anchor.tagName.toLowerCase()=='div';if(this.should_use_absolute){document.body.appendChild(this.dropdown);this.dropdown.className+=' typeahead_list_absolute';}else{if(this.anchor.nextSibling){this.anchor.parentNode.insertBefore(this.dropdown,this.anchor.nextSibling);}else{this.anchor.parentNode.appendChild(this.dropdown);}
if(!this.anchor_block){this.anchor.parentNode.insertBefore(document.createElement('br'),this.dropdown);}}
this.dropdown.appendChild(this.list=document.createElement('div'));this.dropdown.onmousedown=function(event){return this.dropdown_onmousedown(event||window.event);}.bind(this);if(typeaheadpro.should_use_iframe&&!typeaheadpro.iframe){typeaheadpro.iframe=document.createElement('iframe');typeaheadpro.iframe.src="/common/blank.html";typeaheadpro.iframe.className='typeahead_iframe';typeaheadpro.iframe.style.display='none';typeaheadpro.iframe.frameBorder=0;document.body.appendChild(typeaheadpro.iframe);}
this.results_text='';this.last_key_suggestion=0;this.status=typeaheadpro.STATUS_BLOCK_ON_SOURCE_BOOTSTRAP;this.clear_placeholder();if(source){this.set_source(source);}
if(this.source){this.selectedindex=-1;if(this.focused){this.show();this._onkeyup();this.set_class('');this.capture_submit();}}else{this.hide();}}
typeaheadpro.prototype.enumerate=false;typeaheadpro.prototype.interactive=false;typeaheadpro.prototype.changed=false;typeaheadpro.prototype.render_block_size=50;typeaheadpro.STATUS_IDLE=0;typeaheadpro.STATUS_WAITING_ON_SOURCE=1;typeaheadpro.STATUS_BLOCK_ON_SOURCE_BOOTSTRAP=2;typeaheadpro.prototype.should_use_absolute=false;typeaheadpro.prototype.max_results=0;typeaheadpro.prototype.max_display=10;typeaheadpro.prototype.allow_placeholders=true;typeaheadpro.prototype.auto_select=true;typeaheadpro.prototype.set_source=function(source){this.source=source;this.source.set_owner(this);this.status=typeaheadpro.STATUS_IDLE;this.cache={};this.last_search=0;this.suggestions=[];}
typeaheadpro.prototype.setup_anchor=function(){return this.obj;}
typeaheadpro.prototype.destroy=function(){this.clear_render_timeouts();if(!this.anchor_block&&this.anchor.nextSibling.tagName.toLowerCase()=='br'){this.anchor.parentNode.removeChild(this.anchor.nextSibling);}
if(this.dropdown){this.dropdown.parentNode.removeChild(this.dropdown);}
this.obj.onfocus=this.obj.onblur=this.obj.onkeyup=this.obj.onkeydown=this.obj.onkeypress=null;this.obj.parentNode.removeChild(this.obj);this.anchor=this.obj=this.obj.typeahead=this.dropdown=null;delete typeaheadpro.instances[this.instance];}
typeaheadpro.prototype._onkeyup=function(e){this.last_key=e?e.keyCode:-1;if(this.key_down==this.last_key){this.key_down=0;}
switch(this.last_key){case 27:this.selectedindex=-1;this._onselect(false);this.hide();break;case undefined:case 0:case 13:case 37:case 38:case 39:case 40:break;default:this.dirty_results();if(typeaheadpro.should_check_missing_events){setTimeout(function(){this.dirty_results()}.bind(this),50);}
break;}}
typeaheadpro.prototype._onkeydown=function(e){this.key_down=this.last_key=e?e.keyCode:-1;this.interactive=true;switch(this.last_key){case 33:case 34:case 38:case 40:if(typeaheadpro.should_simulate_keypress){this._onkeypress({keyCode:this.last_key});}
return false;case 9:this.select_suggestion(this.selectedindex);this.advance_focus();break;case 13:if(this.select_suggestion(this.selectedindex)){this.hide();}
if(typeof(this.submit_keydown_return)!='undefined'){this.submit_keydown_return=this._onsubmit(this.get_current_selection());}
return this.submit_keydown_return;}}
typeaheadpro.prototype._onkeypress=function(e){var multiplier=1;this.last_key=e?event_get_keypress_keycode(e):-1;this.interactive=true;switch(this.last_key){case 33:multiplier=this.max_display;case 38:this.set_suggestion(multiplier>1&&this.selectedindex>0&&this.selectedindex<multiplier?0:this.selectedindex-multiplier);this.last_key_suggestion=(new Date()).getTime();return false;case 34:multiplier=this.max_display;case 40:if(trim(this.get_value())==''&&!this.enumerate){this.enumerate=true;this.results_text=null;this.dirty_results();}else{this.set_suggestion(this.suggestions.length<=this.selectedindex+multiplier?this.suggestions.length-1:this.selectedindex+multiplier);this.last_key_suggestion=(new Date()).getTime();}
return false;case 13:var ret=null;if(typeof(this.submit_keydown_return)=='undefined'){ret=this.submit_keydown_return=this._onsubmit(this.get_current_selection());}else{ret=this.submit_keydown_return;delete this.submit_keydown_return;}
return ret;}
return true;}
typeaheadpro.prototype._onchange=function(){this.changed=true;}
typeaheadpro.prototype._onfound=function(obj){return this.onfound?this.onfound.call(this,obj):true;}
typeaheadpro.prototype._onsubmit=function(obj){if(this.onsubmit){var ret=this.onsubmit.call(this,obj);if(ret&&this.obj.form){if(!this.obj.form.onsubmit||this.obj.form.onsubmit()){this.obj.form.submit();}
return false;}
return ret;}else{this.advance_focus();return false;}}
typeaheadpro.prototype._onselect=function(obj){if(this.onselect){this.onselect.call(this,obj);}}
typeaheadpro.prototype._onfocus=function(){if(this.last_dropdown_mouse>(new Date()).getTime()-10||this.focused){return;}
this.focused=true;this.changed=false;this.clear_placeholder();this.results_text='';this.set_class('');this.dirty_results();this.show();this.capture_submit();}
typeaheadpro.prototype._onblur=function(event){if(this.last_dropdown_mouse&&this.last_dropdown_mouse>(new Date()).getTime()-10){event_prevent(event);setTimeout(function(){this.focus()}.bind(this.obj),0);return false;}
this.focused=false;if(this.changed&&!this.interactive){this.dirty_results();this.changed=false;return;}
if(!this.suggestions){this._onselect(false);}
this.hide();this.update_class();if(!this.get_value()){var noinput=this.allow_placeholders?'':this.source.gen_noinput();this.set_value(noinput?noinput:'');this.set_class('typeahead_placeholder')}}
typeaheadpro.prototype.dropdown_onmousedown=function(event){this.last_dropdown_mouse=(new Date()).getTime();}
typeaheadpro.prototype.mouse_set_suggestion=function(index){if(!this.visible){return;}
if((new Date()).getTime()-this.last_key_suggestion>50){this.set_suggestion(index);}}
typeaheadpro.prototype.capture_submit=function(){if(!typeaheadpro.should_check_missing_events)return;if((!this.captured_form||this.captured_substitute!=this.captured_form.onsubmit)&&this.obj.form){this.captured_form=this.obj.form;this.captured_event=this.obj.form.onsubmit;this.captured_substitute=this.obj.form.onsubmit=function(){return((this.key_down&&this.key_down!=13&&this.key_down!=9)?this.submit_keydown_return:(this.captured_event?this.captured_event.apply(arguments,this.captured_form):true))?true:false;}.bind(this);}}
typeaheadpro.prototype.set_suggestion=function(index){if(!this.suggestions||this.suggestions.length<=index){return}
var old_node=this.get_suggestion_node(this.selectedindex);this.selectedindex=(index<=-1)?-1:index;var cur_node=this.get_suggestion_node(this.selectedindex);if(old_node){old_node.className=old_node.className.replace(/\btypeahead_selected\b/,'typeahead_not_selected');}
if(cur_node){cur_node.className=cur_node.className.replace(/\btypeahead_not_selected\b/,'typeahead_selected');}
this.recalc_scroll();this._onfound(this.get_current_selection());}
typeaheadpro.prototype.get_suggestion_node=function(index){var nodes=this.list.childNodes;return index==-1?null:nodes[Math.floor(index/this.render_block_size)].childNodes[index%this.render_block_size];}
typeaheadpro.prototype.get_current_selection=function(){return this.selectedindex==-1?false:this.suggestions[this.selectedindex];}
typeaheadpro.prototype.update_class=function(){if(this.suggestions&&this.selectedindex!=-1&&typeahead_source.flatten_string(this.get_current_selection().t)==typeahead_source.flatten_string(this.get_value())){this.set_class('typeahead_found');}else{this.set_class('');}}
typeaheadpro.prototype.select_suggestion=function(index){if(!this.suggestions||index==undefined||index===false||this.suggestions.length<=index||index<0){this._onfound(false);this._onselect(false);this.selectedindex=-1;this.set_class('');}else{this.selectedindex=index;this.set_value(this.suggestions[index].t);this.set_class('typeahead_found');this._onfound(this.suggestions[this.selectedindex]);this._onselect(this.suggestions[this.selectedindex]);}
if(!this.interactive){this.hide();this.obj.blur();}
return true;}
typeaheadpro.prototype.set_value=function(value){this.obj.value=value;}
typeaheadpro.prototype.get_value=function(){return this.obj.value;}
typeaheadpro.prototype.found_suggestions=function(suggestions,text,fake_data){if(!fake_data){this.status=typeaheadpro.STATUS_IDLE;this.add_cache(text,suggestions);}
this.clear_render_timeouts();if(this.get_value()==this.results_text){return;}else if(!fake_data){this.results_text=typeahead_source.flatten_string(text);if(this.enumerate&&trim(this.results_text)!=''){this.enumerate=false;}}
var current_selection=-1;if(this.selectedindex!=-1){var selected_id=this.suggestions[this.selectedindex].i;for(var i=0,l=suggestions.length;i<l;i++){if(suggestions[i].i==selected_id){current_selection=i;break;}}}
if(current_selection==-1&&this.auto_select&&suggestions.length){current_selection=0;this._onfound(suggestions[0]);}
this.selectedindex=current_selection;this.suggestions=suggestions;if(!fake_data){this.real_suggestions=suggestions;}
if(suggestions.length){var html=[],blocks=Math.ceil(suggestions.length/this.render_block_size),must_render={},firstblock,samplenode=null;this.list.innerHTML='';for(var i=0;i<blocks;i++){this.list.appendChild(document.createElement('div'));}
if(current_selection>-1){firstblock=Math.floor(current_selection/this.render_block_size);must_render[firstblock]=true;if(current_selection%this.render_block_size>this.render_block_size/2){must_render[firstblock+1]=true;}else if(firstblock!=0){must_render[firstblock-1]=true;}}else{must_render[0]=true;}
for(var node in must_render){this.render_block(node);sample=this.list.childNodes[node].firstChild;}
this.show();if(blocks){var suggestion_height=sample.offsetHeight;this.render_timeouts=[];for(var i=1;i<blocks;i++){if(!must_render[i]){this.list.childNodes[i].style.height=suggestion_height*Math.min(this.render_block_size,suggestions.length-i*this.render_block_size)+'px';this.list.childNodes[i].style.width='1px';this.render_timeouts.push(setTimeout(this.render_block.bind(this,i),700+i*50));}}}}else{this.selectedindex=-1;this.set_message(this.status==typeaheadpro.STATUS_IDLE?this.source.gen_nomatch():this.source.gen_loading());this._onfound(false);}
this.recalc_scroll();if(!fake_data&&this.results_text!=typeahead_source.flatten_string(this.get_value())){this.dirty_results();}}
typeaheadpro.prototype.render_block=function(block,stack){var suggestions=this.suggestions,selectedindex=this.selectedindex,text=this.get_value(),instance=this.instance,html=[],node=this.list.childNodes[block];for(var i=block*this.render_block_size,l=Math.min(suggestions.length,(block+1)*this.render_block_size);i<l;i++){html.push('<div class="');if(selectedindex==i){html.push('typeahead_suggestion typeahead_selected');}else{html.push('typeahead_suggestion typeahead_not_selected');}
html.push('" onmouseout="typeaheadpro.instances[',instance,'].mouse_set_suggestion(-1)" ','onmouseover="typeaheadpro.instances[',instance,'].mouse_set_suggestion(',i,')" ','onmousedown="typeaheadpro.instances[',instance,'].select_suggestion(',i,'); event_abort(event);">',this.source.gen_html(suggestions[i],text),'</div>');}
node.innerHTML=html.join('');node.style.height='auto';node.style.width='auto';}
typeaheadpro.prototype.clear_render_timeouts=function(){if(this.render_timeouts){for(var i=0;i<this.render_timeouts.length;i++){clearTimeout(this.render_timeouts[i]);}
this.render_timeouts=null;}}
typeaheadpro.prototype.recalc_scroll=function(){var cn=this.list.firstChild;if(!cn){return;}
if(cn.childNodes.length>this.max_display){var last_child=cn.childNodes[this.max_display-1];var height=last_child.offsetTop+last_child.offsetHeight;this.dropdown.style.height=height+'px';var selected=this.get_suggestion_node(this.selectedindex);if(selected){var scrollTop=this.dropdown.scrollTop;if(selected.offsetTop<scrollTop){this.dropdown.scrollTop=selected.offsetTop;}else if(selected.offsetTop+selected.offsetHeight>height+scrollTop){this.dropdown.scrollTop=selected.offsetTop+selected.offsetHeight-height;}}
if(!typeaheadpro.should_use_overflow){this.dropdown.style.overflowY='scroll';this.dropdown.style.overflowX='hidden';}}else{this.dropdown.style.height='auto';if(!typeaheadpro.should_use_overflow){this.dropdown.style.overflowY='hidden';}}}
typeaheadpro.prototype.search_cache=function(text){return this.cache[typeahead_source.flatten_string(text)];}
typeaheadpro.prototype.add_cache=function(text,results){if(this.source.cache_results){this.cache[typeahead_source.flatten_string(text)]=results;}}
typeaheadpro.prototype.update_status=function(status){this.status=status;this.dirty_results();}
typeaheadpro.prototype.set_class=function(name){this.obj.className=(this.obj.className.replace(/typeahead_[^\s]+/g,'')+' '+name).replace(/ {2,}/g,' ');}
typeaheadpro.prototype.dirty_results=function(){if(!this.enumerate&&trim(this.get_value())==''){this.results_text='';this.set_message(this.source.gen_placeholder());this.suggestions=[];this.selectedindex=-1;return;}else if(this.results_text==typeahead_source.flatten_string(this.get_value())){return;}else if(this.status==typeaheadpro.STATUS_BLOCK_ON_SOURCE_BOOTSTRAP){this.set_message(this.source.gen_loading());return;}
var time=(new Date).getTime();var updated=false;if(this.last_search<=(time-this.source.search_limit)&&this.status==typeaheadpro.STATUS_IDLE){updated=this.perform_search();}else{if(this.status==typeaheadpro.STATUS_IDLE){if(!this.search_timeout){this.search_timeout=setTimeout(function(){this.search_timeout=false;if(this.status==typeaheadpro.STATUS_IDLE){this.dirty_results();}}.bind(this),this.source.search_limit-(time-this.last_search));}}}
if(this.source.allow_fake_results&&this.real_suggestions&&!updated){var ttext=typeahead_source.tokenize(this.get_value()).sort(typeahead_source._sort);var fake_results=[];for(var i=0;i<this.real_suggestions.length;i++){if(typeahead_source.check_match(ttext,this.real_suggestions[i].t+' '+this.real_suggestions[i].n)){fake_results.push(this.real_suggestions[i]);}}
if(fake_results.length){this.found_suggestions(fake_results,this.get_value(),true);}else{this.selectedindex=-1;this.set_message(this.source.gen_loading());}}}
typeaheadpro.prototype.perform_search=function(){if(this.get_value()==this.results_text){return true;}
var results;if((results=this.search_cache(this.get_value()))===undefined&&!(results=this.source.search_value(this.get_value()))){this.status=typeaheadpro.STATUS_WAITING_ON_SOURCE;this.last_search=(new Date).getTime();return false;}
this.found_suggestions(results,this.get_value(),false);return true;}
typeaheadpro.prototype.set_message=function(text){this.clear_render_timeouts();if(text){this.list.innerHTML='<div class="typeahead_message">'+text+'</div>';this.reset_iframe();}else{this.hide();}
this.recalc_scroll();}
typeaheadpro.prototype.reset_iframe=function(){if(!typeaheadpro.should_use_iframe){return}
if(this.should_use_absolute){typeaheadpro.iframe.style.top=this.dropdown.style.top;typeaheadpro.iframe.style.left=this.dropdown.style.left;}else{typeaheadpro.iframe.style.top=elementY(this.dropdown)+'px';typeaheadpro.iframe.style.left=elementX(this.dropdown)+'px';}
typeaheadpro.iframe.style.width=this.dropdown.offsetWidth+'px';typeaheadpro.iframe.style.height=this.dropdown.offsetHeight+'px';typeaheadpro.iframe.style.display='';}
typeaheadpro.prototype.advance_focus=function(){var inputs=this.obj.form?get_all_form_inputs(this.obj.form):get_all_form_inputs();var next_inputs=false;for(var i=0;i<inputs.length;i++){if(next_inputs){if(inputs[i].type!='hidden'&&inputs[i].tabIndex!=-1&&inputs[i].offsetParent){next_inputs.push(inputs[i]);}}else if(inputs[i]==this.obj){next_inputs=[];}}
setTimeout(function(){for(var i=0;i<this.length;i++){try{if(this[i].offsetParent){this[i].focus();setTimeout(function(){try{this.focus();}catch(e){}}.bind(this[i]),0);return;}}catch(e){}}}.bind(next_inputs?next_inputs:[]),0);}
typeaheadpro.prototype.clear_placeholder=function(){if(this.obj.className.indexOf('typeahead_placeholder')!=-1){this.set_value('');this.set_class('');}}
typeaheadpro.prototype.clear=function(){this.set_value('');this.set_class('');this.selectedindex=-1;this.enumerate=false;this.dirty_results();}
typeaheadpro.prototype.hide=function(){this.visible=false;if(this.should_use_absolute){this.dropdown.style.display='none';}else{this.dropdown.style.visibility='hidden';}
this.clear_render_timeouts();if(typeaheadpro.should_use_iframe){typeaheadpro.iframe.style.display='none';}}
typeaheadpro.prototype.show=function(){this.visible=true;if(this.focused){if(this.should_use_absolute){this.dropdown.style.top=elementY(this.anchor)+this.anchor.offsetHeight+'px';this.dropdown.style.left=elementX(this.anchor)+'px';}
this.dropdown.style.width=(this.anchor.offsetWidth-2)+'px';this.dropdown.style[this.should_use_absolute?'display':'visibility']='';if(typeaheadpro.should_use_iframe){typeaheadpro.iframe.style.display='';this.reset_iframe();}}}
typeaheadpro.prototype.focus=function(){this.obj.focus();}
typeaheadpro.kill_typeahead=function(obj){if(obj.typeahead){if(!this.should_use_absolute&&!this.anchor_block){obj.parentNode.removeChild(obj.nextSibling);}
obj.parentNode.removeChild(obj.nextSibling);if(obj.typeahead.source){obj.typeahead.source=obj.typeahead.source.owner=null;}
obj.onfocus=obj.onblur=obj.onkeypress=obj.onkeyup=obj.onkeydown=obj.typeahead=null;}}
function tokenizer(obj,typeahead_source,nofocus,max_selections){if(ua.safari()<500){tokenizer.valid_arrow_count=0;tokenizer.valid_arrow_event=function(){return tokenizer.valid_arrow_count++%2==0};}else{tokenizer.valid_arrow_event=function(){return true};}
this.obj=obj;this.obj.tokenizer=this;this.typeahead_source=typeahead_source;while(!/\btokenizer\b/.test(this.obj.className)){this.obj=this.obj.parentNode;}
this.tab_stop=this.obj.getElementsByTagName('input')[0];this.inputs=[];this.obj.onmousedown=function(event){return this._onmousedown(event?event:window.event)}.bind(this);this.tab_stop.onfocus=function(event){return this._onfocus(event?event:window.event)}.bind(this);this.tab_stop.onblur=function(event){return this.tab_stop_onblur(event?event:window.event)}.bind(this);this.tab_stop.onkeydown=function(event){return this.tab_stop_onkeydown(event?event:window.event)}.bind(this);if(!nofocus&&elementY(this.obj)>0){this._onfocus();}
this.max_selections=max_selections;}
tokenizer.is_empty=function(obj){if(has_css_class_name(obj,'tokenizer_locked')){return obj.getElementsByTagName('input').length==0;}else{return(!obj.tokenizer||obj.tokenizer.count_names()==0);}}
tokenizer.prototype.get_token_values=function(){var r=[];var inputs=this.obj.getElementsByTagName('input');for(var i=0;i<inputs.length;++i){if(inputs[i].value){r.push(inputs[i].value);}}
return r;}
tokenizer.prototype.get_token_strings=function(){var r=[];var tokens=this.obj.getElementsByTagName('a');for(var i=0;i<tokens.length;++i){if(typeof tokens[i].token!='undefined'){r.push(tokens[i].token.text);}}
return r;}
tokenizer.prototype.clear=function(){var tokens=this.obj.getElementsByTagName('a');for(var i=tokens.length-1;i>=0;--i){if(typeof tokens[i].token!='undefined'){tokens[i].token.remove();}}}
tokenizer.prototype._onmousedown=function(event){setTimeout(function(){if(!this.inputs.length){if(this.max_selections>this.count_names()){new tokenizer_input(this);}else{var tokens=this.obj.getElementsByTagName('a');for(var i=tokens.length-1;i>=0;i--){if(typeof tokens[i].token!='undefined'){tokens[i].token.select();break;}}}}else{this.inputs[0].focus();}}.bind(this),0);event?event.cancelBubble=true:false;return false;}
tokenizer.prototype._onfocus=function(event){if(this.tab_stop_ignore_focus){this.tab_stop_ignore_focus=false;return;}
this._onmousedown();}
tokenizer.prototype.tab_stop_onblur=function(event){this.selected_token?this.selected_token.deselect():false;}
tokenizer.prototype.tab_stop_onkeydown=function(event){if(!event.keyCode||!this.selected_token){return;}
switch(event.keyCode){case 8:case 46:var tok=this.selected_token;var prev=tok.element.previousSibling;if(prev&&prev.input){prev.input.element.focus();}else{new tokenizer_input(this,tok.element);}
tok.remove();return false;case 37:if(!tokenizer.valid_arrow_event()){break;}
var tok=this.selected_token;var prev=tok.element.previousSibling;if(prev&&prev.input){prev.input.element.focus();}else if(this.max_selections>this.count_names()){new tokenizer_input(this,tok.element);}else{return false;}
tok.deselect();return false;case 39:if(!tokenizer.valid_arrow_event()){break;}
var tok=this.selected_token;var next=tok.element.nextSibling;if(next&&next.input){next.input.focus();}else if(this.max_selections>this.count_names()){new tokenizer_input(this,tok.element.nextSibling);}else{return false;}
tok.deselect();return false;}}
tokenizer.prototype.count_names=function(plus){var inputs=this.obj.getElementsByTagName('input');var uniq={};var count=0;for(var i=0;i<inputs.length;i++){if(inputs[i].type=='hidden'&&!uniq[inputs[i].value]){uniq[inputs[i].value]=true;++count;}}
if(plus){for(var j=0;j<plus.length;j++){if(!uniq[plus[j]]){uniq[plus[j]]=true;++count;}}}
return count;}
tokenizer.prototype.disable=function(){this.tab_stop.parentNode.removeChild(this.tab_stop);this.obj.className+=' tokenizer_locked';}
function tokenizer_input(tokenizer,caret){if(!tokenizer_input.hacks){tokenizer_input.should_use_borderless_hack=ua.safari();tokenizer_input.should_use_shadow_hack=ua.ie()||ua.opera();tokenizer_input.hacks=true;}
this.tokenizer=tokenizer;this.obj=document.createElement('input');this.obj.input=this;this.obj.tabIndex=-1;this.obj.size=1;this.obj.onmousedown=function(event){(event?event:window.event).cancelBubble=true}.bind(this);this.shadow=document.createElement('span');this.shadow.className='tokenizer_input_shadow';this.element=document.createElement('div');this.element.className='tokenizer_input'+(tokenizer_input.should_use_borderless_hack?' tokenizer_input_borderless':'');this.element.appendChild(document.createElement('div'));this.element.firstChild.appendChild(this.obj);(tokenizer_input.should_use_shadow_hack?document.body:this.element.firstChild).appendChild(this.shadow);caret?tokenizer.obj.insertBefore(this.element,caret):tokenizer.obj.appendChild(this.element);this.tokenizer.tab_stop.disabled=true;this.update_shadow();this.update_shadow=this.update_shadow.bind(this);this.tokenizer.inputs.push(this);this.parent.construct(this,this.obj,this.tokenizer.typeahead_source);if(this.focused){this.focus();this.obj.select();}
setInterval(this.update_shadow.bind(this),100);}
tokenizer_input.extend(typeaheadpro);tokenizer_input.prototype.gen_nomatch=tokenizer_input.prototype.gen_loading=tokenizer_input.prototype.gen_placeholder=tokenizer_input.prototype.gen_noinput='';tokenizer_input.prototype.max_display=8;tokenizer_input.prototype.setup_anchor=function(){return this.tokenizer.obj;}
tokenizer_input.prototype.update_shadow=function(){try{var val=this.obj.value;}catch(e){return};if(this.shadow_input!=val){this.shadow.innerHTML=htmlspecialchars((this.shadow_input=val)+'^_^');if(tokenizer_input.should_use_shadow_hack){this.obj.style.width=this.shadow.offsetWidth+'px';this.obj.value=val;}}}
tokenizer_input.prototype._onblur=function(){if(this.parent._onblur()===false){return false;}
if(this.changed&&!this.interactive){this.dirty_results();this.changed=false;return;}
if(this.changed||this.interactive){this.select_suggestion(this.selectedindex);}
setTimeout(function(){this.disabled=false}.bind(this.tokenizer.tab_stop),1000);this.destroy();}
tokenizer_input.prototype._onfocus=function(){this.tokenizer.tab_stop.disabled=true;this.parent._onfocus();return true;}
tokenizer_input.prototype._onkeydown=function(event){switch(event.keyCode){case 13:if(this.selectedindex<0&&this.suggestions.length){this.selectedindex=0;}
break;case 37:case 8:if(this.get_selection_start()!=0||this.obj.value!=''){break;}
var prev=this.element.previousSibling;if(prev&&prev.token){setTimeout(prev.token.select.bind(prev.token),0);}
break;case 39:case 46:if(this.get_selection_start()!=this.obj.value.length){break;}
var next=this.element.nextSibling;if(next&&next.token){setTimeout(next.token.select.bind(next.token),0);}
break;case 188:this._onkeydown({keyCode:9});return false;case 9:if(this.obj.value){this.advance_focus();this._onkeydown({keyCode:13});return false;}else if(!event.shiftKey){this.advance_focus();this.parent._onkeydown(event);return false;}
break;}
return this.parent._onkeydown(event);}
tokenizer_input.prototype._onkeypress=function(event){switch(event.keyCode){case 9:return false;}
setTimeout(this.update_shadow,0);return this.parent._onkeypress(event);}
tokenizer_input.prototype.select_suggestion=function(index){if(this.suggestions&&index>=0&&this.suggestions.length>index){var inputs=this.tokenizer.obj.getElementsByTagName('input');var id=this.suggestions[index].i;for(i=0;i<inputs.length;i++){if(inputs[i].name=='ids[]'&&inputs[i].value==id){return false;}}}
return this.parent.select_suggestion(index);}
tokenizer_input.prototype.get_selection_start=function(){if(this.obj.selectionStart!=undefined){return this.obj.selectionStart;}else{return Math.abs(document.selection.createRange().moveStart('character',-1024));}}
tokenizer_input.prototype.onselect=function(obj){if(obj){var inputs=this.tokenizer.obj.getElementsByTagName('input');for(i=0;i<inputs.length;i++){if(inputs[i].name=='ids[]'&&inputs[i].value==obj.i){return false;}}
new token(obj,this.tokenizer,this.element);if(this.tokenizer.max_selections>this.tokenizer.count_names()){this.clear();}else{this.destroy();this.hide=function(){};return false;}}
this.tokenizer.typeahead_source.onselect_not_found.call(this);return false;}
tokenizer_input.prototype._onsubmit=function(){return false;}
tokenizer_input.prototype.capture_submit=function(){return false;}
tokenizer_input.prototype.clear=function(){this.parent.clear();this.update_shadow();}
tokenizer_input.prototype.destroy=function(){if(tokenizer_input.should_use_shadow_hack){this.shadow.parentNode.removeChild(this.shadow);}
this.element.parentNode.removeChild(this.element);this.element=null;var index=array_indexOf(this.tokenizer.inputs,this);if(index!=-1){this.tokenizer.inputs.splice(index,1);}
this.tokenizer=this.element=this.shadow=null;this.parent.destroy();return null;}
function token(obj,tokenizer,caret){if(obj.is&&(tokenizer.count_names(obj.is)>tokenizer.max_selections)){(new contextual_dialog).set_context(tokenizer.obj).show_prompt(tx('ta12'),tx('ta13')).fade_out(500,1500);return null;}
this.tokenizer=tokenizer;this.element=document.createElement('a');this.element.className='token';this.element.href='#';this.element.tabIndex=-1;this.element.onclick=function(event){return this._onclick(event?event:window.event)}.bind(this);this.element.onmousedown=function(event){(event?event:window.event).cancelBubble=true;return false};this.render_obj(obj);this.element.token=this;caret?this.tokenizer.obj.insertBefore(this.element,caret):this.tokenizer.obj.appendChild(this.element);}
token.prototype.render_obj=function(obj){var inputs='';if(obj.np){var fb_protected='';}else{var fb_protected='fb_protected="true" ';}
if(obj.e){inputs=['<input type="hidden" ',fb_protected,'name="emails[]" value="',obj.e,'" />'].join('');}else if(obj.i){inputs=['<input type="hidden" ',fb_protected,'name="',this.tokenizer.obj.id,'[]" value="',obj.i,'" />'].join('');}else if(obj.is){for(var i=0,il=obj.is.length;i<il;i++){inputs+=['<input type="hidden" ',fb_protected,'name="',this.tokenizer.obj.id,'[]" value="',obj.is[i],'" />'].join('');}
this.explodable=true;this.n=obj.n;}
this.text=obj.t;this.element.innerHTML=['<span><span><span><span>',inputs,htmlspecialchars(obj.t),'<span onclick="this.parentNode.parentNode.parentNode.parentNode.parentNode.token.remove(true); event.cancelBubble=true; return false;" ','onmouseover="this.className=\'x_hover\'" onmouseout="this.className=\'x\'" class="x">&nbsp;</span>','</span></span></span></span>'].join('');}
token.prototype._onclick=function(event){var this_select_time=(new Date()).getTime();if(this.explodable&&this.tokenizer.last_select_time&&(this_select_time-this.tokenizer.last_select_time<1400)){var to_add=this.n;this.remove();var inputs=this.tokenizer.obj.getElementsByTagName('input');var already_ids={};for(var i=0;i<inputs.length;++i){if(inputs[i].name=='ids[]'){already_ids[inputs[i].value]=true;}}
for(var id in to_add){if(!already_ids[id]){new token({'t':to_add[id],'i':id},this.tokenizer);}}}else{this.select();}
this.tokenizer.last_select_time=this_select_time;event.cancelBubble=true;return false;}
token.prototype.select=function(again){if(this.tokenizer.selected_token&&!again){this.tokenizer.selected_token.deselect();}
this.element.className=trim(this.element.className.replace('token_selected',''))+' token_selected';this.tokenizer.tab_stop_ignore_focus=true;if(this.tokenizer.tab_stop.disabled){this.tokenizer.tab_stop.disabled=false;}
this.tokenizer.tab_stop.focus();this.tokenizer.selected_token=this;if(again!==true){setTimeout(function(){this.select(true)}.bind(this),0);}else{setTimeout(function(){this.tab_stop_ignore_focus=false}.bind(this.tokenizer),0);}}
token.prototype.remove=function(focus){this.element.parentNode.removeChild(this.element);this.element.token=null;this.tokenizer.selected_token=null;if(focus){this.tokenizer._onmousedown();}}
token.prototype.deselect=function(){this.element.className=trim(this.element.className.replace('token_selected',''));this.tokenizer.selected_token=null;}
function typeahead_source(){}
typeahead_source.prototype.cache_results=false;typeahead_source.prototype.enumerable=false;typeahead_source.prototype.allow_fake_results=false;typeahead_source.prototype.search_limit=10;typeahead_source.check_match=function(search,value){value=typeahead_source.tokenize(value);for(var i=0,il=search.length;i<il;i++){if(search[i].length){var found=false;for(var j=0,jl=value.length;j<jl;j++){if(value[j].length>=search[i].length&&value[j].substring(0,search[i].length)==search[i]){found=true;value[j]='';break;}}
if(!found){return false;}}}
return true;}
typeahead_source.tokenize=function(text,capture,noflatten){return(noflatten?text:typeahead_source.flatten_string(text)).split(capture?typeahead_source.normalizer_regex_capture:typeahead_source.normalizer_regex);}
typeahead_source.normalizer_regex_str='(?:(?:^| +)["\'.\\-]+ *)|(?: *[\'".\\-]+(?: +|$)|@| +)';typeahead_source.normalizer_regex=new RegExp(typeahead_source.normalizer_regex_str,'g');typeahead_source.normalizer_regex_capture=new RegExp('('+typeahead_source.normalizer_regex_str+')','g');typeahead_source.flatten_string=function(text){if(!typeahead_source.accents){typeahead_source.accents={a:/à|á|â|ã|ä|å/g,c:/ç/g,d:/ð/g,e:/è|é|ê|ë/g,i:/ì|í|î|ï/g,n:/ñ/g,o:/ø|ö|õ|ô|ó|ò/g,u:/ü|û|ú|ù/g,y:/ÿ|ý/g,ae:/æ/g,oe:/œ/g}}
text=text.toLowerCase();for(var i in typeahead_source.accents){text=text.replace(typeahead_source.accents[i],i);}
return text;}
typeahead_source.prototype.set_owner=function(obj){this.owner=obj;if(this.is_ready){this.owner.update_status(typeaheadpro.STATUS_IDLE);}}
typeahead_source.prototype.ready=function(){if(this.owner&&!this.is_ready){this.is_ready=true;this.owner.update_status(typeaheadpro.STATUS_IDLE);}else{this.is_ready=true;}}
typeahead_source.highlight_found=function(result,search){var html=[];resultv=typeahead_source.tokenize(result,true,true);result=typeahead_source.tokenize(result,true);search=typeahead_source.tokenize(search);search.sort(typeahead_source._sort);for(var i=0,il=resultv.length;i<il;i++){var found=false;for(var j=0,jl=search.length;j<jl;j++){if(search[j]&&result[i].lastIndexOf(search[j],0)!=-1){html.push('<em>',htmlspecialchars(resultv[i].substring(0,search[j].length)),'</em>',htmlspecialchars(resultv[i].substring(search[j].length,resultv[i].length)));found=true;break;}}
if(!found){html.push(htmlspecialchars(resultv[i]));}}
return html.join('');}
typeahead_source._sort=function(a,b){return b.length-a.length;}
typeahead_source.prototype.gen_nomatch=function(){return this.text_nomatch!=null?this.text_nomatch:tx('ta01');}
typeahead_source.prototype.gen_loading=function(){return this.text_loading!=null?this.text_loading:tx('ta02');}
typeahead_source.prototype.gen_placeholder=function(){return this.text_placeholder!=null?this.text_placeholder:tx('ta03');}
typeahead_source.prototype.gen_noinput=function(){return this.text_noinput!=null?this.text_noinput:tx('ta03');}
typeahead_source.prototype.onselect_not_found=function(){if(typeof this.tokenizer.onselect!='undefined'){return this.tokenizer.onselect();}}
function static_source(){this.values=null;this.index=null;this.exclude_ids={};this.parent.construct(this);}
static_source.extend(typeahead_source);static_source.prototype.enumerable=true;static_source.prototype.build_index=function(){var index=[];var values=this.values;var gen_id=values.length&&typeof values[0].i=='undefined';for(var i=0,il=values.length;i<il;i++){var tokens=typeahead_source.tokenize(values[i].t);for(var j=0,jl=tokens.length;j<jl;j++){index.push({t:tokens[j],o:values[i]});}
if(gen_id){values[i].i=i;}}
index.sort(function(a,b){return(a.t==b.t)?0:(a.t<b.t?-1:1)});this.index=index;this.ready();}
static_source.prototype._sort_text_obj=function(a,b){if(a.e&&!b.e){return 1;}
if(!a.e&&b.e){return-1;}
if(a.t==b.t){return 0;}
return a.t<b.t?-1:1}
static_source.prototype.search_value=function(text){if(!this.is_ready){return;}
var results;if(text==''){results=this.values;}else{var ttext=typeahead_source.tokenize(text).sort(typeahead_source._sort);var index=this.index;var lo=0;var hi=this.index.length-1;var p=Math.floor(hi/2);while(lo<=hi){if(index[p].t>=ttext[0]){hi=p-1;}else{lo=p+1;}
p=Math.floor(lo+((hi-lo)/2));}
var results=[];var stale_keys={};var check_ignore=typeof _ignoreList!='undefined';for(var i=lo;i<index.length&&index[i].t.lastIndexOf(ttext[0],0)!=-1;i++){var elem_id=index[i].o.flid?index[i].o.flid:index[i].o.i;if(typeof stale_keys[elem_id]!='undefined'){continue;}else{stale_keys[elem_id]=true;}
if((!check_ignore||!_ignoreList[elem_id])&&!this.exclude_ids[elem_id]&&(ttext.length==1||typeahead_source.check_match(ttext,index[i].o.t))){results.push(index[i].o);}}}
results.sort(this._sort_text_obj);if(this.owner.max_results){results=results.slice(0,this.owner.max_results);}
return results;}
static_source.prototype.set_exclude_ids=function(ids){this.exclude_ids=ids;}
function friend_source(get_param){this.parent.construct(this);if(friend_source.friends[get_param]){this.values=friend_source.friends[get_param];this.index=friend_source.friends_index[get_param];this.ready();}else{var ajax=new Ajax(function(obj,text){text=text.substring(9);eval(text);friend_source.friends[get_param]=this.values=friends;this.build_index();friend_source.friends_index[get_param]=this.index;}.bind(this));ajax.get('/ajax/typeahead_friends.php?'+get_param);}}
friend_source.extend(static_source);friend_source.prototype.text_noinput=friend_source.prototype.text_placeholder=tx('ta04');friend_source.friends={};friend_source.friends_index={};friend_source.prototype.cache_results=true;friend_source.prototype.gen_html=function(friend,highlight){var text=friend.n;if(typeof(friend.n)=="object"){var names=[];for(var k in friend.n){names.push(friend.n[k]);}
text=names.join(', ');}
return['<div>',typeahead_source.highlight_found(friend.t,highlight),'</div><div><small>',text,'</small></div>'].join('');}
friend_source.prototype.search_value=function(text){if(text=='\x5e\x5f\x5e'){return[{t:text,n:'\x6b\x65\x6b\x65',i:10,it:'http://static.ak.facebook.com/pics/t_default.jpg'}];}
return this.parent.search_value(text);}
function friend_and_email_source(get_param){get_param=get_param?get_param+'&include_emails=1':'';this.parent.construct(this,get_param);}
friend_and_email_source.extend(friend_source);friend_and_email_source.prototype.text_noinput=friend_and_email_source.prototype.text_placeholder=tx('ta05');friend_and_email_source.prototype.text_nomatch=tx('ta06');friend_and_email_source.prototype.onselect_not_found=function(){emails=this.results_text.split(/[,; ]/);for(var i=0;i<emails.length;i++){var text=emails[i].replace(/^\s+|\s+$/g,'');var email_regex=/.*\@.*\.[a-z]+$/;if(!email_regex.test(text)){continue;}
var email_entry={t:text,e:text};var new_token=new token(email_entry,this.tokenizer,this.element);var ajax=new Ajax(function(obj,text){text=(text.length>9)?text.substring(9):'';eval(text);if(obj){this.render_obj(obj);}}.bind(new_token));ajax.get('/ajax/typeahead_email.php?email='+encodeURIComponent(text));}
this.clear();}
function network_source(get_param){this.get_param=get_param?get_param:'';this.parent.construct(this);this.ready();}
network_source.extend(typeahead_source);network_source.prototype.cache_results=true;network_source.prototype.search_limit=200;network_source.prototype.text_placeholder=network_source.prototype.text_noinput=tx('ta07');network_source.prototype.base_uri='';network_source.prototype.allow_fake_results=true;network_source.prototype.search_value=function(text){this.search_text=text;var ajax=new Ajax(function(ajax,text){eval(text);this.owner.found_suggestions(results,this.search_text);}.bind(this),function(){this.owner.found_suggestions(false,this.search_text);}.bind(this));ajax.get('/ajax/typeahead_networks.php?'+this.get_param+'&q='+encodeURIComponent(text));}
network_source.prototype.gen_html=function(result,highlight){return['<div>',typeahead_source.highlight_found(result.t,highlight),'</div><div><small>',typeahead_source.highlight_found(result.l,highlight),'</small></div>'].join('');}
function extended_network_source(get_param){this.get_param=get_param?get_param:'';this.parent.construct(this);this.ready();}
extended_network_source.extend(network_source);extended_network_source.prototype.search_value=function(text){this.search_text=text;var ajax=new Ajax(function(ajax,text){eval(text);this.owner.found_suggestions(results,this.search_text);}.bind(this),function(){this.owner.found_suggestions(false,this.search_text);}.bind(this));var extraParams='';if(this.hs_ineligible){extraParams+='&hs_ineligible';}
if(this.geo_ineligible){extraParams+='&geo_ineligible';}
if(this.type){extraParams+='&type=';for(var i in this.type){extraParams+=this.type[i]+'_';}}
ajax.get('/ajax/typeahead_extended_networks.php?'+this.get_param+'&q='+encodeURIComponent(text)+'&network_type&show_email'+extraParams);}
function custom_source(options){this.parent.construct(this);this.values=options;this.build_index();}
custom_source.extend(static_source);custom_source.prototype.text_placeholder=custom_source.prototype.text_noinput=false;custom_source.prototype.gen_html=function(result,highlight){var html=['<div>',typeahead_source.highlight_found(result.t,highlight),'</div>'];if(result.s){html.push('<div><small>',friend.n,'</small></div>');}
return html.join('');}
function concentration_source(get_network){this.parent.construct(this,[]);this.network=get_network;if(!concentration_source.networks){concentration_source.networks=[];}else{for(var i=0,il=concentration_source.networks.length;i<il;i++){if(concentration_source.networks[i].n==this.network){this.values=concentration_source.networks[i].v;this.index=concentration_source.networks[i].i;this.ready();return;}}}
new AsyncRequest().setURI('/ajax/typeahead_concentrations.php?n='+this.network).setHandler(function(response){this.values=response.getPayload();this.build_index();concentration_source.networks.push({n:this.network,v:this.values,i:this.index});this.ready();}.bind(this)).send();}
concentration_source.extend(custom_source);concentration_source.prototype.noinput=false;concentration_source.prototype.text_placeholder=tx('ta08');concentration_source.prototype.allow_fake_results=true;function language_source(){this.parent.construct(this,[]);if(!language_source.languages){language_source.languages=[];}else{for(var i=0,il=language_source.languages.length;i<il;i++){this.values=language_source.languages[i].v;this.index=language_source.languages[i].i;this.ready();return;}}
new AsyncRequest().setURI('/ajax/typeahead_languages.php').setHandler(function(response){this.values=response.getPayload();this.build_index();language_source.languages.push({v:this.values,i:this.index});this.ready();}.bind(this)).send();}
language_source.extend(custom_source);language_source.prototype.noinput=false;language_source.prototype.text_placeholder=tx('ta14');language_source.prototype.allow_fake_results=false;function keyword_source(get_category){this.parent.construct(this,[]);this.category=get_category;if(!keyword_source.categories){keyword_source.categories=[];}else{for(var i=0,il=keyword_source.categories.length;i<il;i++){if(keyword_source.categories[i].c==this.category){this.values=keyword_source.categories[i].v;this.index=keyword_source.categories[i].i;this.ready();return;}}}
var ajax=new Ajax(function(obj,text){eval(text);this.values=_results;this.build_index();keyword_source.categories.push({c:this.category,v:this.values,i:this.index});this.ready();}.bind(this));ajax.get('/ajax/typeahead_keywords.php?c='+this.category);}
keyword_source.extend(custom_source);keyword_source.prototype.noinput=false;keyword_source.prototype.text_placeholder=tx('ta09');function regions_source(get_iso2){this.parent.construct(this,[]);this.country=get_iso2;this.reload();}
regions_source.extend(custom_source);regions_source.prototype.noinput=false;regions_source.prototype.text_placeholder=tx('ta10');regions_source.prototype.reload=function(){var ajax=new Ajax(function(obj,text){eval(text);this.values=_results;this.build_index();this.ready();}.bind(this));ajax.get('/ajax/typeahead_regions.php?c='+this.country);}
function time_source(get_param){this.get_param=get_param?get_param:'';this.status=0;this.parent.construct(this);}
time_source.extend(typeahead_source);time_source.prototype.cache_results=true;time_source.prototype.text_placeholder=time_source.prototype.text_noinput=tx('ta11');time_source.prototype.base_uri='';time_source.prototype.search_value=function(text){this.search_text=text;var ajax=new Ajax(function(ajax,text){eval(text);this.owner.found_suggestions(results,this.search_text,false);}.bind(this),function(){this.owner.found_suggestions(false,this.search_text,false);}.bind(this));ajax.get('/ajax/typeahead_time.php?'+this.get_param+'&q='+encodeURIComponent(text));}
time_source.prototype.gen_html=function(result,highlight){return['<div>',typeahead_source.highlight_found(result.t,highlight),'</div>'].join('');}
function dynamic_custom_source(async_url){this.async_url=async_url;this.parent.construct(this);}
dynamic_custom_source.extend(typeahead_source);dynamic_custom_source.cache_results=true;dynamic_custom_source.prototype.search_value=function(text){this.search_text=text;var r=new AsyncRequest().setURI(this.async_url).setData({'q':text}).setHandler(bind(this,function(r){eval('var results = ('+r.payload+')');this.owner.found_suggestions(results,this.search_text,false);})).setErrorHandler(bind(this,function(r){this.owner.found_suggestions(false,this.search_text,false);})).setReadOnly(true).send()}
dynamic_custom_source.prototype.gen_html=function(result,highlight){var html=['<div>',this.highlight_found(result.t,highlight),'</div>'];if(result.s){html.push('<div class="sub_result"><small>',result.s,'</small></div>');}
return html.join('');}
dynamic_custom_source.prototype.highlight_found=function(result,search){return typeahead_source.highlight_found(result,search);}