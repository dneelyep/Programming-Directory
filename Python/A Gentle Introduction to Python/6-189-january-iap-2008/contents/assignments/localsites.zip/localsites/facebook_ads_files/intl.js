
function intl_translation_init(){addEventBase(document.body,'mousedown',intl_translation_onmousedown);addEventBase(document.body,'mouseout',intl_translation_onmouseout);}
function intl_get_translatable_parent(obj){while(obj.parentNode){if(obj.className=='intl-translatable'||obj.className=='intl-authored'||obj.className=='intl-translated'){return obj;}
obj=obj.parentNode;}
return null;}
var intl_translation_last_mousedown=null;function intl_translation_onclick(e){var target=event_get_target(e);if(target.intl_ignore_click){target.intl_ignore_click=false;return event_abort(e)||event_prevent(e);}
target=intl_get_translatable_parent(target);if(!target){return;}
var modes={'intl-authored':0,'intl-translated':1,'intl-translatable':2};var hash=null,mode=null,locale=null;var data=target.getAttribute('intl_data').split(':');mode=modes[target.className];hash=data[0];locale=data[1];intl_show_dialog(target,mode,hash,locale);target.intl_click_delay=false;return event_abort(e)||event_prevent(e);}
function intl_translation_onmousedown(e){intl_translation_last_mousedown=event_get_target(e);var target=intl_get_translatable_parent(intl_translation_last_mousedown);if(!target){return;}
if(!target.intl_bootstrapped){target.intl_bootstrapped=true;addEventBase(target,'click',intl_translation_onclick);}
target.intl_click_delay=true;setTimeout(function(){if(target.intl_click_delay){intl_translation_last_mousedown.intl_ignore_click=true;while(intl_translation_last_mousedown.parentNode){if(intl_translation_last_mousedown!=target){if(intl_translation_last_mousedown.onclick&&intl_translation_last_mousedown.onclick()===false){break;}
if(intl_translation_last_mousedown.tagName=='A'){goURI(intl_translation_last_mousedown.href);}}
intl_translation_last_mousedown=intl_translation_last_mousedown.parentNode;}}},400);}
function intl_translation_onmouseout(e){var target=event_get_target(e);target.intl_click_delay=false;}
function intl_show_dialog(clickedElement,c,h,l){var dialog=new contextual_dialog('intl_inline_translation_dialog');dialog.set_context(clickedElement);var u=document.location;dialog.show_ajax_dialog('/ajax/intl/inline_translation_dialog.php'
+'?u='+u
+'&c='+c
+'&h='+h
+'&l='+l);}
function intl_submit_translation_dialog(clickedElement,h,l,v){var location=new String(document.location);var strings=location.split('&p=');var p=0;if(strings[1]){p=strings[1];}
var s=null;var i=null;var id1=location.search(/&id=/);var id2=null;if((id2=location.search(/&popular/))!=-1){s='popular';}else if((id2=location.search(/&disputed/))!=-1){s='disputed';}else if((id2=location.search(/&recent/))!=-1){s='recent';}
if(id1&&id2){i=location.substr(id1+4,id2-(id1+4));}
var dialog=new contextual_dialog('intl_submit_translation_dialog');dialog.set_context(clickedElement);dialog.show_ajax_dialog('/ajax/intl/submit_translation_dialog.php'
+'?h='+h
+'&l='+l
+'&i='+i
+'&s='+s
+'&p='+p
+'&v='+v);}
function intl_delete_translation_dialog(clickedElement,h,l,v){var dialog=new contextual_dialog('intl/delete_translation_dialog');dialog.set_context(clickedElement);dialog.show_ajax_dialog('/ajax/intl/delete_translation_dialog.php'
+'?h='+h
+'&l='+l
+'&v='+v);}
function intl_report_translation_dialog(clickedElement,h,t,l){onResponse=function(asyncResponse){var report_dialog=asyncResponse.getPayload();var dialog=new contextual_dialog();function onSubmit(){var c=$('report_dialog_code').value;new AsyncRequest().setURI('/ajax/intl/do_report.php').setData({'hash':h,'translation_id':t,'locale':l,'report_code':c}).setHandler(function(){dialog.hide();}).setErrorHandler(function(){dialog.hide();}).send();}
dialog.set_context(clickedElement);dialog.show_choice(report_dialog['title'],report_dialog['markup'],'Report',onSubmit,'Cancel',function(){dialog.hide();return false;});}
onError=function(asyncResponse){}
new AsyncRequest().setURI('/ajax/intl/report_translation_dialog.php').setData({'hash':h,'translation_id':t,'locale':l}).setHandler(bind(this,onResponse)).setErrorHandler(bind(this,'onError')).send();}
function intl_vote_translation_dialog(clickedElement,t,l){var dialog=new contextual_dialog('intl/vote_translation_dialog');dialog.set_context(clickedElement);dialog.show_ajax_dialog('/ajax/intl/vote_translation_dialog.php'
+'?t='+t
+'&l='+l);}
function intl_reload_page_locale(obj){var locale=obj.options[obj.selectedIndex].value;var location=new String(document.location);var prefix=location.split('&locale=');var redirect=prefix[0]+'&locale='+locale;document.location=redirect;}
function intl_show_highlight_schemes(){show(ge('highlight_schemes'));}
function intl_hide_highlight_schemes(){hide(ge('highlight_schemes'));}
function intl_set_locale(obj){var locale=obj.options[obj.selectedIndex].value;(new AsyncRequest()).setURI('/ajax/intl/save_locale.php').setData({locale:locale}).setHandler(function(){document.location.reload();}).send();}
function intl_set_sortby(obj){var sortby=obj.options[obj.selectedIndex].value;var location=new String(document.location);location=location.replace(/&recent/g,"");location=location.replace(/&disputed/g,"");location=location.replace(/&popular/g,"");var parts=location.split('&p=');if(parts.length==2){document.location=parts[0]+'&'+sortby+'&p='+parts[1];}else{document.location=location+'&'+sortby;}}
function intl_set_xmode(obj){var checked=obj.checked;var xmode=1;if(checked==false){xmode=0;}
(new AsyncRequest()).setURI('/ajax/intl/save_xmode.php').setData({xmode:xmode}).setHandler(function(){document.location.reload();}).send();}
function intl_set_pmode(obj){var checked=obj.checked;var pmode=1;if(checked==false){pmode=0;}
(new AsyncRequest()).setURI('/ajax/intl/save_xmode.php').setData({pmode:pmode}).setHandler(function(){document.location.reload();}).send();}
function votes_noun(val){if(((val)==1)||((val)==-1)){var nouns='vote';}else{var nouns='votes'}
return nouns;}
function intl_do_vote(native_hash,locale,translation_id,vote){ajax=new Ajax();ajax.onDone=function(ajaxObj,response){eval(response);var total=data_votes;var ups=data_up;var downs=Math.abs(data_down);$('total_'+native_hash+'_'+translation_id).innerHTML=(total);$('vtext_'+native_hash+'_'+translation_id).innerHTML=votes_noun(total);show($('total_'+native_hash+'_'+translation_id));show($('vtext_'+native_hash+'_'+translation_id));$('ups_'+native_hash+'_'+translation_id).innerHTML=(ups)+' '+' up,';$('downs_'+native_hash+'_'+translation_id).innerHTML=(downs)+' '+' down';if(vote==1){var ids=tr_ids[native_hash];for(i=0;i<ids.length;i++){c_name=$('voteup_'+native_hash+'_'+ids[i]).className;if(c_name=='upselect'&&ids[i]!=translation_id){$('voteup_'+native_hash+'_'+ids[i]).className='upover';cur_vote=($('ups_'+native_hash+'_'+ids[i]).innerHTML.split(' up,'))[0];$('ups_'+native_hash+'_'+ids[i]).innerHTML=(cur_vote-1)+' '+' up,';}}
$('voteup_'+native_hash+'_'+translation_id).className='upselect';$('votedown_'+native_hash+'_'+translation_id).className='downover';}
if(vote==-1){$('votedown_'+native_hash+'_'+translation_id).className='downselect';$('voteup_'+native_hash+'_'+translation_id).className='upover';}}
ajax.onFail=function(ajaxObj){}
var params="hash="+native_hash
+"&vote="+vote
+"&locale="+locale
+"&translation_id="+translation_id;ajax.post('/ajax/intl/do_vote.php',params);}
function tx(str,args){str=_string_table[str];if(args){if(typeof args!='object'){Util.error('intl.js: the 2nd argument must be a keyed array (not a string) for tx('+str+', ...)');}else{for(var key in args){var regexp=new RegExp('\{'+key+'\}',"g");str=str.replace(regexp,args[key]);}}}
return str;}
function intl_translation_dialog(native_str,form,anchors,tokens,glossary,rules){this.form=form;this.textarea=form.getElementsByTagName('textarea')[0];this.anchors=[];this.anchor_states=[];this.tokens=tokens;this.glossary=glossary;this.rules=rules;this.native_str=native_str;if(anchors){anchors=anchors.getElementsByTagName('a');for(var i=0;i<anchors.length;i++){this.anchors.push(anchors[i]);anchors[i].onclick=this.insert_token.bind(null,this);this.anchor_states.push(false);}}
this.textarea.onkeypress=this.refresh_tokens.bind(this);this.textarea.onkeyup=this.refresh_tokens.bind(this);this.form.intl_submit.onclick=this.submit_click.bind(this);}
intl_translation_dialog.prototype.insert_token=function(that){var index=that.get_anchor_index(this),textarea=that.textarea,pos=get_caret_position(that.textarea).end;textarea.value=textarea.value.substring(0,pos)+that.tokens[index]+textarea.value.substring(pos);textarea.focus();that.anchor_states[index]=true;hide(this);return false;}
intl_translation_dialog.prototype.get_anchor_index=function(anchor){for(var i=0;i<this.anchors.length;i++){if(this.anchors[i]==anchor){return i;}}
return-1;}
intl_translation_dialog.prototype.refresh_tokens=function(){var active_tokens=/{[^}]+}/g,token=null,tokens={};for(var i=0;i<this.tokens.length;i++){tokens[this.tokens[i]]=false;}
while(token=active_tokens.exec(this.textarea.value)){tokens[token[0]]=true;}
for(var i=0;i<this.anchors.length;i++){if(tokens[this.tokens[i]]!=this.anchor_states[i]){this.anchor_states[i]=!this.anchor_states[i];(this.anchor_states[i]?hide:show)(this.anchors[i]);}}}
intl_translation_dialog.prototype.check_tokens=function(){for(var i=0;i<this.anchor_states.length;i++){if(!this.anchor_states[i]){return false;}}
return true;}
intl_translation_dialog.prototype.rule_canon=function(native_str,translated){var words=translated.toLowerCase().split(/\b([^\s]+?)\b/);if(this.glossary){for(var i=0;i<this.glossary.length;i++){if(array_indexOf(words,this.glossary[i])==-1){return'Recommended glossary translations not used.';}}}}
intl_translation_dialog.prototype.rule_punctuation=function(native_str,translated){var punctuation=[',','.','?','!',';',':'];for(var i=0;i<punctuation.length;i++){if(substr_count(native_str,punctuation[i])!=substr_count(translated,punctuation[i])){return'Punctuation mismatch. Did you forget a period or other punctuation?';}}}
intl_translation_dialog.prototype.rule_capitalization=function(native_str,translated){if(((native_str.substring(0,1).toLowerCase()!=native_str.substring(0,1))!=(translated.substring(0,1).toLowerCase()!=translated.substring(0,1)))&&(native_str.substring(0,1)+translated.substring(0,1)).indexOf('{')==-1){return'Capitalization mismatch. Make sure the casing of your translation is accurate.';}}
intl_translation_dialog.prototype.check_warnings=function(native_str,translated){var warnings=[];for(var i=0;i<this.rules.length;i++){var warning=this['rule_'+this.rules[i]](native_str,translated);if(warning){warnings.push(warning);}}
return warnings.length?warnings:null;}
intl_translation_dialog.prototype.translation_exist=function(){var form=ge('intl_ajax');var exist;var onResponse=function(asyncResponse){var result=asyncResponse.getPayload();exist=result['exist'];}
new AsyncRequest().setURI('/ajax/intl/check_translation_exist.php').setData({'hash':form.hash.value,'translation':form.translation.value}).setHandler(onResponse).setErrorHandler(function(){dialog.hide();}).setOption('asynchronous',false).send();return exist;}
intl_translation_dialog.prototype.submit_click=function(){var person,warnings;if(person=this.translation_exist()){var form=ge('intl_ajax');if(form){uid=form.user.value;}
var person_str=(person==uid)?'You have':'Someone has';var dialog=(new pop_dialog()).show_choice('Duplicate Translation','Sorry! '+person_str+' already submited the same translation.','Edit Translation',function(){dialog.hide();}.bind(this),'Review Translations',function(){var form=ge('intl_ajax');document.location='/translations/?vote&hash='+form.hash.value;});}else if(!this.check_tokens()){var dialog=(new pop_dialog()).show_message('Unused Tokens','You did not use all the tokens while translating this string. '+'Please make sure you maintain all text in curly braces ( <b>{example}</b> ) in the translation.');}else if(warnings=this.check_warnings(this.native_str,this.textarea.value)){var dialog=(new pop_dialog()).show_choice('Translation Warning','There may be a problem with your translation! '+'The translation you provided failed the following style check'+(warnings.length==1?'':'s')+': <br />'+'<ul><li>'+warnings.join('</li><li>')+'</li></ul><br />'+'It\'s ok to ignore '+(warnings.length==1?'this warning':'these warnings')+' if it makes sense given the context of the phrase, but please make sure that this is the case.','Submit Translation',function(){dialog.hide();this.form.submit();generic_dialog.get_dialog(this.form).hide();}.bind(this),'Review Translation',function(){dialog.hide();});}else{this.form.submit();generic_dialog.get_dialog(this.form).hide();}}
function intl_show_legal_dialog(){var dialog=new pop_dialog();dialog.show_choice('Terms Applicable to Translate Facebook'
+'<br/><small>Date of Last Revision: December 13, 2007</small>','The Translate Facebook application collects translations, comments, suggestions, ideas, feedback and other information ("Submissions") from you and other users in connection with Facebook\'s language translation project to provide Facebook access in multiple languages (the "Project").'
+'<br/><br/>You understand that your participation in the Project is for the benefit of the Facebook user community as it will allow users whose participation is currently limited by language to more fully participate.  You acknowledge that your participation in the Project is entirely voluntary, and you understand that no monetary or other compensation will be given to persons, including you, for Submissions.  You may provide as much or as little input into the Project as you wish and can cease contributing to the Project at any time.'
+'<br/><br/>In consideration of Facebook\'s permitting you to participate in the Project and the benefits to the Facebook user community of which you are a member, you acknowledge and agree that any Submissions that you provide to Facebook will be owned by Facebook.  Accordingly, you irrevocably assign to Facebook all right, title and interest, including all intellectual property rights, in and to all Submissions, and Facebook is entitled to the unrestricted use and dissemination of these Submissions for any purpose, commercial or otherwise, without acknowledgment, consent or monetary or other tangible compensation to you.  To the extent that the foregoing assignment is or becomes invalid or unenforceable to any degree or for any reason, you grant Facebook an irrevocable, perpetual, exclusive, fully-paid-up, royalty-free, worldwide right and license, with the right to sublicense, to use, reproduce, display, perform, create derivative works of, distribute and otherwise exploit the Submissions in any manner.'
+'<br/><br/>Please note: Translate Facebook is subject to and governed by these Additional Terms Applicable to Translate Facebook (the "Additional Terms") as well as the <a href="/terms.php">Facebook Terms of Use</a>. In the event of any conflict between these Additional Terms and the Facebook Terms of Use, these Additional Terms control. Capitalized terms that are not defined in these Additional Terms will have the definitions provided them in the Terms of Use.  Facebook reserves the right, in our sole discretion, to change, modify, add, or delete portions of these Additional Terms at any time without further notice. If we do this, we will post the changes to these Additional Terms on this page and will indicate at the top of this page the date these terms were last revised. You agree to waive any specific notice of such changes, and your continued use and operation of Translate Facebook after any such changes constitutes your acceptance of the new Additional Terms. It is your responsibility to regularly check the Site to determine if there have been changes to these Additional Terms.','Close',function(){generic_dialog.get_dialog(this).hide()});}
function intl_disable_rooster_save(obj){var save=document.getElementById('install_translation_app');save.disabled=!obj.checked;var container=document.getElementById('install_container');if(obj.checked){container.style.display='block';}else{container.style.display='none';}}
function intl_confirm_rooster_and_install_app(uid,divid){document.location='add.php?api_key=efa7a7045708fcadede8d705e39b1642';}
function substr_count(haystack,needle){var count=0,pos=haystack.indexOf(needle);while(pos!=-1){count++;pos=haystack.indexOf(needle,pos+1);}
return count;}
function intl_help_preview(obj){var dialog=new contextual_dialog();dialog.set_context(obj);dialog.show_message('Preview Mode','Check this box to see Facebook using the '+'translations that are currently most highly voted. '+'Some messages may still be in English if Facebook '+'has not been fully translated into your language yet.'+'<br/><br/>'+'If you see a translation that looks wrong, you can '+'click the "Translate While Browsing" box that is '+'available when you are in preview mode; that will '+'allow you to vote on any of the existing translations '+'you see, or suggest new ones of your own.','Okay',function(){dialog.hide();});}
function intl_help_translate(obj){var dialog=new contextual_dialog();dialog.set_context(obj);dialog.show_message('Translate While Browsing','Check this box to vote on translations or suggest '+'new ones of your own while you use Facebook. '+'<br/><br/>'+'With this box checked, clicking on any underlined '+'phrase will give you a small translation control '+'panel. If you want to click on a link to go to '+'another page, rather than to see the control '+'panel, just hold down the mouse button for '+'at least 1 second.'+'<br/><br/>'+'Red underlined phrases have not been translated yet. '+'Yellow underlined phrases were translated by you. '+'Green underlined phrases were translated by someone '+'else.','Okay',function(){dialog.hide();});}